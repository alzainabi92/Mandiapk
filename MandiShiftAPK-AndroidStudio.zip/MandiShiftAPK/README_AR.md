# تطبيق مندي جنوب اليمن لإدارة الدوام

هذا مشروع Android Studio يحوّل ملف HTML المرفق إلى تطبيق Android باستخدام WebView، مع الإبقاء على واجهة النظام ووظائفه الحالية.

## إنشاء ملف APK
1. ثبّت Android Studio على الكمبيوتر.
2. فك ضغط الملف وافتح مجلد `MandiShiftAPK` من Android Studio عبر **Open**.
3. انتظر اكتمال Gradle Sync وثبّت Android SDK Platform 35 إذا طلبه البرنامج.
4. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. بعد نجاح البناء اختر **locate** للحصول على ملف APK.

## ملاحظات
- بيانات الحضور والإعدادات تحفظ محلياً داخل WebView على الجهاز.
- يحتاج تحميل خط Cairo ومكتبة html2canvas إلى اتصال إنترنت لأن ملف HTML الأصلي يستدعيهما من الإنترنت.
- هذه نسخة أولية غير موقعة للنشر على المتجر؛ Android Studio ينشئ APK تجريبياً قابلاً للتثبيت. للنشر العام أنشئ توقيع Release من Build > Generate Signed Bundle / APK.
